package com.freebeat.music;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

public class PlaybackService extends Service {
    public static final String ACTION_PLAY = "com.freebeat.music.PLAY";
    public static final String ACTION_STOP = "com.freebeat.music.STOP";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_ARTIST = "artist";
    private static final String CHANNEL_ID = "freebeat_playback";
    private PowerManager.WakeLock wakeLock;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_PLAY : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopForeground(true);
            releaseWakeLock();
            stopSelf();
            return START_NOT_STICKY;
        }
        String title = intent == null ? "FreeBeat" : intent.getStringExtra(EXTRA_TITLE);
        String artist = intent == null ? "Muzikë" : intent.getStringExtra(EXTRA_ARTIST);
        Notification notification = buildNotification(title, artist);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(7, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(7, notification);
        }
        acquireWakeLock();
        return START_STICKY;
    }

    private Notification buildNotification(String title, String artist) {
        Intent openApp = new Intent(this, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pending = PendingIntent.getActivity(this, 0, openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title == null || title.isEmpty() ? "FreeBeat" : title)
                .setContentText((artist == null || artist.isEmpty() ? "Po luan muzikë" : artist) + " · Dëgjim në sfond")
                .setContentIntent(pending).setOngoing(true).setOnlyAlertOnce(true).build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "FreeBeat playback", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Njoftimi gjatë dëgjimit të muzikës në sfond");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null && (wakeLock == null || !wakeLock.isHeld())) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "FreeBeat:Playback");
                wakeLock.acquire(4 * 60 * 60 * 1000L);
            }
        } catch (Exception ignored) { }
    }
    private void releaseWakeLock() {
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) { }
        wakeLock = null;
    }
    @Override public void onDestroy() { releaseWakeLock(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
