package com.freebeat.music;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.webkit.JavascriptInterface;
import android.net.Uri;
import android.content.Intent;

public class MainActivity extends Activity {
    private WebView webView;

    public class PlaybackBridge {
        @JavascriptInterface
        public void searchYoutube(String query) {
            if (query == null || query.trim().isEmpty()) return;
            final String url = "https://m.youtube.com/results?search_query=" + Uri.encode(query.trim());
            runOnUiThread(() -> webView.loadUrl(url));
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(9,11,22));
        getWindow().setNavigationBarColor(Color.rgb(9,11,22));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(9,11,22));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setUserAgentString(settings.getUserAgentString().replace("; wv", ""));
        webView.addJavascriptInterface(new PlaybackBridge(), "FreeBeatNative");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // Keep YouTube pages and video playback inside FreeBeat, never launch the YouTube app.
                if (url != null && (url.startsWith("https://www.youtube.com/") ||
                    url.startsWith("https://m.youtube.com/") ||
                    url.startsWith("https://youtube.com/") ||
                    url.startsWith("https://youtu.be/"))) {
                    String clean = url.replace("https://www.youtube.com/", "https://m.youtube.com/");
                    view.loadUrl(clean);
                    return true;
                }
                if (url != null && url.startsWith("http")) {
                    view.loadUrl(url);
                    return true;
                }
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
