FreeBeat - YouTube search in-app prototype

This Android project opens a branded FreeBeat search screen, then loads YouTube mobile search results in the same WebView (it does not launch the YouTube app intentionally).

Important limitations:
- Search/video pages are served by YouTube and can change or block WebView playback.
- YouTube's policies and technical restrictions mean background playback is not guaranteed.
- This is a source project ZIP, not an already-built APK.
- Build with Android Studio or the existing GitHub Actions workflow.
