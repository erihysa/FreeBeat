package com.eribeat.music;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;
    public class PlaybackBridge {
        @JavascriptInterface public void startPlayback(String title, String artist) {
            runOnUiThread(() -> {
                Intent i = new Intent(MainActivity.this, PlaybackService.class);
                i.setAction(PlaybackService.ACTION_PLAY);
                i.putExtra(PlaybackService.EXTRA_TITLE, title);
                i.putExtra(PlaybackService.EXTRA_ARTIST, artist);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i); else startService(i);
            });
        }
        @JavascriptInterface public void stopPlayback() {
            runOnUiThread(() -> { Intent i = new Intent(MainActivity.this, PlaybackService.class); i.setAction(PlaybackService.ACTION_STOP); startService(i); });
        }
    }
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(9,11,18));
        getWindow().setNavigationBarColor(Color.rgb(9,11,18));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(9,11,18));
        WebSettings s = webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(true); s.setAllowFileAccess(true); s.setAllowContentAccess(false);
        // Permit the bundled local UI to call the HTTPS music API from WebView.
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        webView.addJavascriptInterface(new PlaybackBridge(), "ERiBeatNative");
        webView.setWebViewClient(new WebViewClient()); webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView); webView.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onPause() { super.onPause(); }
    @Override public void onBackPressed() {
        webView.evaluateJavascript("document.getElementById('nowPlaying') && !document.getElementById('nowPlaying').classList.contains('hidden')", value -> {
            if ("true".equals(value)) webView.evaluateJavascript("document.getElementById('nowPlaying').classList.add('hidden')", null);
            else if (webView.canGoBack()) webView.goBack(); else finish();
        });
    }
}
