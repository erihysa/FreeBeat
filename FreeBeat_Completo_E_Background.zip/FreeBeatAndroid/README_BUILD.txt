FREEBEAT — PROJEKTI ANDROID
===========================

Përmban logon E, kërkimin e muzikës, luajtjen brenda aplikacionit dhe shërbimin për dëgjim në sfond.

KËRKESA TË RËNDËSISHME
- Ky është projekti burimor, jo APK i gatshëm për instalim.
- Kërkimi dhe muzika kërkojnë internet dhe përdorin katalogun Jamendo.
- Jamendo ka kryesisht muzikë të pavarur; nuk garanton këngë të artistëve të famshëm komercialë.
- Shërbimi në sfond shfaq njoftim Android, por duhet testuar në pajisje reale.
- Për publikim, regjistro një client ID tëndin në Jamendo dhe kontrollo kushtet/licencat.

SI TË NDËRTOHET APK
1. Në kompjuter, hap FreeBeatAndroid në Android Studio.
2. Lejo Gradle të sinkronizohet dhe instalo SDK-të që kërkohen.
3. Zgjidh Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK-ja debug gjendet te app/build/outputs/apk/debug/app-debug.apk.

Ky projekt nuk është ndërtuar/testuar në pajisje në këtë mjedis.
