FreeBeat - free music catalog prototype

Features: Jamendo catalog search, playback for tracks available through the catalog, one locally stored playlist, next/previous controls, E app logo, no SoundCloud/YouTube login.

Important: the catalog is not every commercial hit. This is a source ZIP, not a built APK. The Jamendo demo client ID is for prototyping and may have limits; register a proper app/client ID for release. Background playback in WebView is device-dependent and has not been verified; a reliable production implementation should use a native Android media playback service and media notification.

Build using Android Studio or the existing GitHub Actions setup.
