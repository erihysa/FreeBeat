FREEBEAT ANDROID PROJECT
========================

This is Android Studio source code, not a compiled APK.

BUILD AN APK
1. Install Android Studio on a computer.
2. Open the folder named FreeBeatAndroid as an existing project.
3. Allow Android Studio to sync Gradle and install the Android SDK components it requests.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be placed under app/build/outputs/apk/debug/app-debug.apk.

NOTES
- Music search/playback requires internet and uses Jamendo's public test client ID in assets/index.html.
- Replace CLIENT_ID with your registered Jamendo application ID before public release; check API terms and individual music licenses.
- The app does not ask listeners to log in and does not include app-owned analytics or ads.
- Search requests are sent to Jamendo; the music provider receives the query and standard network metadata.
- This project has not been compiled or tested on a device in this environment.
